// Main Quant Lab homepage composition
const { useState, useEffect, useRef } = React;

function Nav() {
  return <SiteNav active="home" />;
}

function Hero({ tweaks }) {
  const today = new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
  return (
    <section className="hero" data-screen-label="Hero">
      <div className="wrap">
        <div className="hero__grid">
          <div className="hero__left">
            <div className="hero__meta">
              <span className="dot" />
              <span>Vol. III · Issue 04</span>
              <span className="sep" />
              <span>{today.toUpperCase()}</span>
              <span className="sep" />
              <span>Budapest · Vienna</span>
            </div>
            <h1 className="h1 hero__title">
              Turning Research <br />
              into{" "}
              {tweaks.headlineStyle === "Serif accent"
                ? <em className="accent-underline">Market Insight.</em>
                : <span style={{ color: "var(--primary)" }}>Market Insight.</span>}
            </h1>
            <p className="hero__sub">
              CEU Quant Lab is a student-led applied research initiative in finance,
              data science, strategy, and markets, publishing institutional-grade
              analysis and connecting academia with industry at Central European University.
            </p>
            <div className="hero__ctas">
              <a href="#articles" className="btn btn--primary">
                Read the Research <Arrow />
              </a>
              <a href="#partner" className="btn btn--ghost">
                Partner With Us
              </a>
            </div>
          </div>

          <aside className="hero__aside" aria-label="Featured quote">
            <HeroGeometry
              primary={tweaks.primary}
              secondary={tweaks.secondary}
              accent={tweaks.accent}
            />
            <div className="hero__aside-top">
              <span className="hero__aside-kicker">Featured Note</span>
              <span className="hero__aside-id">QL-2026.04</span>
            </div>
            <div className="hero__aside-bottom">
              <div className="hero__aside-label">On the desk</div>
              <div className="hero__aside-quote">
                “Central Europe’s equity premium is mispriced — and the data tells a
                different story than the consensus.”
              </div>
              <div className="hero__aside-meta">
                <span>M. Kováč</span>
                <span style={{ opacity: 0.4 }}>·</span>
                <span>Equity Strategy Desk</span>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}

function Credibility() {
  const items = [
    { num: "300", unit: "+", label: "Participants across cohorts and live events" },
    { num: "12", unit: "", label: "Applied research notes published this year" },
    { num: "4", unit: "", label: "Desks: Equity · Macro · AI · Data" },
    { num: "2", unit: "", label: "CEU partners — Career Services and Economics" },
    { num: "18", unit: "", label: "Industry-facing roundtables and panels" },
  ];
  return (
    <section className="credibility" data-screen-label="Credibility" aria-label="By the numbers">
      <div className="wrap">
        <div className="credibility__grid">
          {items.map((it, i) => (
            <div key={i} className="credibility__item">
              <div className="credibility__num">
                {it.num}<span className="unit">{it.unit}</span>
              </div>
              <div className="credibility__label">{it.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function WhatWeDo() {
  const items = [
    { num: "01", title: "Market Insights", desc: "Weekly desk notes on CEE equities, FX, rates and commodities — written for practitioners." },
    { num: "02", title: "Quantitative Research", desc: "Peer-reviewed working papers on factor pricing, risk premia and systematic strategies." },
    { num: "03", title: "Strategy & Consulting", desc: "Applied case work on business strategy, competitive analysis, and market entry — in partnership with industry." },
    { num: "04", title: "AI & Data Science", desc: "Machine learning for alpha discovery, NLP on filings, and alternative-data pipelines." },
    { num: "05", title: "Industry Events", desc: "Closed-door roundtables with banks, consultancies and asset managers at CEU." },
  ];
  return (
    <section className="section" id="research" data-screen-label="What we do">
      <div className="wrap">
        <div className="section__head">
          <div>
            <div className="section__eyebrow-row">
              <span className="line" />
              <span className="num">01 — Capabilities</span>
            </div>
            <h2 className="h2">What we do at the Lab.</h2>
          </div>
          <p>
            Five disciplines, one standard. Every output — whether a research note, a
            dataset, or a roundtable — is built to the level of institutional practice,
            then published openly for the academic community.
          </p>
        </div>
        <div className="capabilities">
          {items.map((it) => <Capability key={it.num} {...it} />)}
        </div>
      </div>
    </section>
  );
}

function Articles() {
  return (
    <section className="section" id="articles" data-screen-label="Articles">
      <div className="wrap">
        <div className="section__head">
          <div>
            <div className="section__eyebrow-row">
              <span className="line" />
              <span className="num">02 — Research</span>
            </div>
            <h2 className="h2">Latest from the desk.</h2>
          </div>
          <p>
            Analysis from our Equity, Macro, AI and Data desks. New notes ship every
            Monday; long-form working papers quarterly.
          </p>
        </div>

        <div className="articles">
          <Article
            lead
            cat="Equity Strategy"
            date="22 APR 2026"
            title="The CEE Risk Premium: why discount rates remain elevated after two cut cycles"
            dek="A decomposition of equity returns across Hungary, Poland and Czechia suggests a structural, not cyclical, risk premium persists — with implications for allocation across the region."
            author="M. Kováč & T. Bauer"
            initials="MK"
            variant="chart"
            tone="teal"
          />
          <Article
            cat="AI in Finance"
            date="18 APR 2026"
            title="Transformer models for credit-spread forecasting: a 10-year backtest"
            dek="Attention-based architectures outperform linear baselines by 14% in out-of-sample RMSE on EUR investment-grade spreads."
            author="L. Horváth"
            initials="LH"
            variant="area"
            tone="paper"
          />
          <Article
            cat="Macro"
            date="11 APR 2026"
            title="ECB reaction functions and the euro-area neutral rate"
            dek="Re-estimating r-star for the euro area using a Bayesian state-space model with structural breaks post-2022."
            author="A. Varga"
            initials="AV"
            variant="bars"
            tone="teal2"
          />
        </div>

        <div style={{ marginTop: 40, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 16 }}>
          <div className="row" style={{ gap: 10, flexWrap: "wrap" }}>
            <span className="chip"><span className="dot" /> 12 notes this quarter</span>
            <span className="chip">Archive: 68 papers</span>
          </div>
          <a href="#" className="hlink">
            Browse all research <Arrow />
          </a>
        </div>
      </div>
    </section>
  );
}

function Partners() {
  const partners = [
    { name: "CEU Career Services", sub: "Institutional Partner" },
    { name: "CEU Department of Economics", sub: "Academic Partner" },
    { name: "Budapest Stock Exchange", sub: "Data Partner" },
    { name: "Erste Group Research", sub: "Industry Partner" },
    { name: "Morgan Stanley CEE", sub: "Industry Partner" },
    { name: "Bloomberg Terminal Lab", sub: "Technology Partner" },
    { name: "MNB Research", sub: "Institutional Partner" },
    { name: "McKinsey & Company", sub: "Industry Partner" },
  ];
  return (
    <section className="section section--tight" id="partners" data-screen-label="Partners" style={{ background: "var(--paper-2)" }}>
      <div className="wrap">
        <div className="section__head">
          <div>
            <div className="section__eyebrow-row">
              <span className="line" />
              <span className="num">03 — Network</span>
            </div>
            <h2 className="h2">An institutional network.</h2>
          </div>
          <p>
            We work with academic departments, central banks, asset managers and
            investment banks to ensure our research meets the rigour of industry practice.
          </p>
        </div>
        <div className="partners">
          {partners.map((p, i) => (
            <div key={i} className="partner">
              <div className="partner__name">
                {p.name}
                <span>{p.sub}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FinalCTA({ tweaks }) {
  return (
    <section className="finalCta" id="partner" data-screen-label="Final CTA">
      <CtaGeometry secondary={tweaks.secondary} accent={tweaks.accent} />
      <div className="wrap">
        <div className="finalCta__grid">
          <div>
            <div style={{
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase",
              color: "rgba(255,255,255,0.6)", marginBottom: 20,
            }}>
              Get involved — Spring 2026 intake open
            </div>
            <h2>
              Work with <em>Quant Lab.</em>
            </h2>
          </div>
          <div className="finalCta__aside">
            <p>
              Join as a member, commission applied research, or host a roundtable with
              our analysts. We respond within three business days.
            </p>
            <div className="finalCta__ctas">
              <a href="#" className="btn btn--on-dark">
                Join as a member <Arrow />
              </a>
              <a href="#" className="btn btn--on-dark-ghost">
                Partner with us
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return <SiteFooter />;
}

// Tweaks UI — wires into the host editor protocol
function Tweaks({ tweaks, setTweak }) {
  const { TweaksPanel, TweakSection, TweakColor, TweakRadio, TweakToggle } = window;
  if (!TweaksPanel) return null;
  return (
    <TweaksPanel title="Tweaks">
      <TweakSection label="Palette">
        <TweakColor label="Primary" value={tweaks.primary} onChange={v => setTweak("primary", v)} />
        <TweakColor label="Secondary" value={tweaks.secondary} onChange={v => setTweak("secondary", v)} />
        <TweakColor label="Accent" value={tweaks.accent} onChange={v => setTweak("accent", v)} />
        <TweakColor label="Paper" value={tweaks.paper} onChange={v => setTweak("paper", v)} />
        <TweakColor label="Ink" value={tweaks.ink} onChange={v => setTweak("ink", v)} />
      </TweakSection>
      <TweakSection label="Hero">
        <TweakRadio
          label="Headline style"
          value={tweaks.headlineStyle}
          options={["Serif accent", "Solid teal"]}
          onChange={v => setTweak("headlineStyle", v)}
        />
      </TweakSection>
      <TweakSection label="Modules">
        <TweakToggle label="Show market ticker" value={tweaks.showTicker} onChange={v => setTweak("showTicker", v)} />
        <TweakToggle label="Show brand banner" value={tweaks.showBanner} onChange={v => setTweak("showBanner", v)} />
      </TweakSection>
    </TweaksPanel>
  );
}

// Optional banner strip using the provided asset
function BrandBanner() {
  return (
    <div style={{ background: "var(--primary)", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
      <div className="wrap" style={{ padding: "0" }}>
        <img
          src="assets/quantlab-banner.png"
          alt="CEU Quant Lab — Turning Research into Market Insight"
          style={{ width: "100%", display: "block", maxHeight: 180, objectFit: "cover", objectPosition: "center" }}
        />
      </div>
    </div>
  );
}

function App() {
  const useTweaks = window.useTweaks;
  const [tweaks, setTweak] = useTweaks
    ? useTweaks(window.__TWEAKS__)
    : [window.__TWEAKS__, () => {}];

  // Apply color tweaks as CSS variables
  useEffect(() => {
    const r = document.documentElement.style;
    r.setProperty("--primary", tweaks.primary);
    r.setProperty("--secondary", tweaks.secondary);
    r.setProperty("--accent", tweaks.accent);
    r.setProperty("--paper", tweaks.paper);
    r.setProperty("--ink", tweaks.ink);
    document.body.style.background = tweaks.paper;
  }, [tweaks.primary, tweaks.secondary, tweaks.accent, tweaks.paper, tweaks.ink]);

  return (
    <>
      <Nav />
      {tweaks.showBanner && <BrandBanner />}
      <Hero tweaks={tweaks} />
      {tweaks.showTicker && <Ticker />}
      <Credibility />
      <WhatWeDo />
      <Articles />
      <Partners />
      <FinalCTA tweaks={tweaks} />
      <Footer />
      <Tweaks tweaks={tweaks} setTweak={setTweak} />
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
