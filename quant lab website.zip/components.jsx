// Shared UI atoms for Quant Lab
const { useState, useEffect, useRef, useMemo } = React;

// Logo mark — a clean, original institutional lockup using the brand colors.
// Uses the provided square asset as the brand mark where appropriate.
function BrandLockup({ variant = "dark", size = "md" }) {
  const heights = { sm: 28, md: 36, lg: 44, xl: 56 };
  const h = heights[size] || heights.md;
  const tileBg = variant === "onTeal" ? "#ffffff" : "#0B4E5C";
  const tileFg = variant === "onTeal" ? "#0B4E5C" : "#ffffff";
  const nameColor = variant === "onTeal" ? "#ffffff" : "#0B4E5C";
  const subColor = variant === "onTeal" ? "rgba(255,255,255,0.7)" : "#5A6A6F";
  return (
    <div style={{ display: "inline-flex", alignItems: "center", gap: h * 0.32 }}>
      <div
        style={{
          width: h, height: h, borderRadius: Math.max(6, h * 0.18),
          background: tileBg, color: tileFg,
          display: "grid", placeItems: "center",
          fontWeight: 700, fontSize: h * 0.34, letterSpacing: "0.02em",
          fontFamily: "Inter, sans-serif",
          flex: "0 0 auto",
        }}
      >CEU</div>
      <div style={{ display: "flex", flexDirection: "column", lineHeight: 1 }}>
        <div style={{
          fontFamily: "Inter, sans-serif",
          fontWeight: 600,
          fontSize: h * 0.52,
          letterSpacing: "-0.012em",
          color: nameColor,
        }}>
          Quant<span style={{ fontWeight: 400 }}>Lab</span>
        </div>
        <div style={{
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: h * 0.22,
          letterSpacing: "0.18em",
          textTransform: "uppercase",
          color: subColor,
          marginTop: h * 0.13,
        }}>
          Data · Finance · Business
        </div>
      </div>
    </div>
  );
}

// Geometric angled background shapes inspired by the provided banner.
function HeroGeometry({ primary = "#0B4E5C", secondary = "#2C7A8A", accent = "#4AA3B0" }) {
  return (
    <svg className="hero__aside-shapes" viewBox="0 0 400 500" preserveAspectRatio="none" aria-hidden="true">
      <defs>
        <clipPath id="heroClip"><rect width="400" height="500" /></clipPath>
      </defs>
      <g clipPath="url(#heroClip)">
        <rect width="400" height="500" fill={primary} />
        {/* Wide angled ray from top-right */}
        <polygon points="400,0 400,280 140,500 60,500" fill={secondary} opacity="0.9" />
        {/* Narrow secondary ray */}
        <polygon points="400,60 400,220 260,500 210,500" fill={accent} opacity="0.55" />
        {/* Subtle bottom-left shape */}
        <polygon points="0,500 0,360 180,500" fill="#000000" opacity="0.12" />
        {/* Thin stroke accent */}
        <line x1="0" y1="0" x2="400" y2="160" stroke="rgba(255,255,255,0.08)" strokeWidth="1" />
      </g>
    </svg>
  );
}

// Large decorative shapes for the final CTA band.
function CtaGeometry({ secondary = "#2C7A8A", accent = "#4AA3B0" }) {
  return (
    <svg className="finalCta__shapes" viewBox="0 0 1440 600" preserveAspectRatio="none" aria-hidden="true">
      <polygon points="1440,0 1440,420 980,600 820,600" fill={secondary} opacity="0.55" />
      <polygon points="1440,120 1440,300 1180,600 1080,600" fill={accent} opacity="0.35" />
      <polygon points="0,600 0,520 180,600" fill="rgba(255,255,255,0.04)" />
    </svg>
  );
}

// Editorial thumbnail placeholders — geometric, institutional, no AI slop.
function ArticleThumb({ variant = "chart", tone = "paper" }) {
  const bgMap = {
    teal: "#0B4E5C",
    teal2: "#2C7A8A",
    paper: "#EFEEE8",
    ink: "#0E1B1F",
  };
  const bg = bgMap[tone];
  const fg = tone === "paper" ? "#0B4E5C" : "#ffffff";
  const dim = tone === "paper" ? "#C7C6C0" : "rgba(255,255,255,0.18)";

  return (
    <div className="art__thumb" style={{ background: bg, borderColor: tone === "paper" ? "#D9DAD4" : "transparent" }}>
      <svg viewBox="0 0 320 200" preserveAspectRatio="none" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
        {/* Gridlines */}
        {[40, 80, 120, 160].map(y => (
          <line key={y} x1="0" y1={y} x2="320" y2={y} stroke={dim} strokeWidth="0.5" />
        ))}
        {variant === "chart" && (
          <>
            <polyline fill="none" stroke={fg} strokeWidth="1.75"
              points="10,150 40,140 70,120 100,125 130,100 160,90 190,95 220,70 250,55 280,58 310,40" />
            <polyline fill="none" stroke={fg} strokeWidth="1" strokeDasharray="3 3" opacity="0.55"
              points="10,160 40,155 70,145 100,150 130,130 160,125 190,130 220,110 250,100 280,105 310,85" />
            <circle cx="310" cy="40" r="3" fill={fg} />
          </>
        )}
        {variant === "bars" && (
          <g>
            {[20, 50, 80, 110, 140, 170, 200, 230, 260, 290].map((x, i) => {
              const h = [60, 90, 45, 110, 75, 140, 95, 120, 65, 150][i];
              return <rect key={x} x={x} y={180 - h} width="14" height={h} fill={fg} opacity={i % 2 ? 0.55 : 0.95} />;
            })}
          </g>
        )}
        {variant === "scatter" && (
          <g fill={fg}>
            {Array.from({ length: 28 }).map((_, i) => {
              const x = 20 + (i * 11) % 280 + (i % 3) * 4;
              const y = 40 + ((i * 37) % 130);
              const r = 1.8 + (i % 4) * 0.6;
              return <circle key={i} cx={x} cy={y} r={r} opacity={0.5 + (i % 5) * 0.1} />;
            })}
          </g>
        )}
        {variant === "area" && (
          <g>
            <path d="M0,180 L0,120 C40,100 80,140 120,110 C160,80 200,90 240,70 C280,55 310,65 320,50 L320,200 L0,200 Z" fill={fg} opacity="0.2" />
            <path d="M0,120 C40,100 80,140 120,110 C160,80 200,90 240,70 C280,55 310,65 320,50" stroke={fg} strokeWidth="1.5" fill="none" />
          </g>
        )}
      </svg>
      <div style={{
        position: "absolute", left: 12, top: 12,
        fontFamily: "'JetBrains Mono', monospace", fontSize: 10, letterSpacing: "0.16em",
        color: tone === "paper" ? "#5A6A6F" : "rgba(255,255,255,0.6)",
        textTransform: "uppercase",
      }}>
        Fig. 01
      </div>
    </div>
  );
}

// Ticker component — smooth, finance-platform feel with subtle live-value drift.
function Ticker() {
  const base = [
    { sym: "STOXX 600", val: 512.48, chg: +0.42, fmt: "idx" },
    { sym: "EUR/USD",   val: 1.0842, chg: -0.11, fmt: "fx"  },
    { sym: "BUX",       val: 74218,  chg: +0.88, fmt: "idx0"},
    { sym: "DAX",       val: 18204,  chg: +0.31, fmt: "idx0"},
    { sym: "BTP 10Y",   val: 3.82,   chg: -0.04, fmt: "yld" },
    { sym: "BRENT",     val: 83.14,  chg: +1.05, fmt: "idx" },
    { sym: "GOLD",      val: 2348,   chg: +0.22, fmt: "idx0"},
    { sym: "VSTOXX",    val: 14.62,  chg: -3.10, fmt: "idx" },
    { sym: "BUND 10Y",  val: 2.41,   chg: +0.02, fmt: "yld" },
    { sym: "SPX",       val: 5214,   chg: +0.18, fmt: "idx0"},
    { sym: "WIG20",     val: 2382,   chg: +0.53, fmt: "idx0"},
    { sym: "USD/HUF",   val: 362.14, chg: -0.24, fmt: "idx" },
  ];
  const [tick, setTick] = React.useState(0);
  React.useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 2800);
    return () => clearInterval(id);
  }, []);

  // Deterministic sub-basis-point drift so values feel live but stable between renders.
  const fmt = (it) => {
    const drift = (Math.sin((tick + it.sym.length) * 1.7) + Math.cos(tick * 0.9 + it.sym.charCodeAt(0))) * 0.0008;
    const v = it.val * (1 + drift);
    if (it.fmt === "fx")   return v.toFixed(4);
    if (it.fmt === "yld")  return v.toFixed(2) + "%";
    if (it.fmt === "idx0") return Math.round(v).toLocaleString("en-US");
    return v.toFixed(2);
  };
  const chg = (it) => {
    const c = it.chg + Math.sin((tick + it.sym.charCodeAt(1)) * 0.8) * 0.02;
    const up = c >= 0;
    const abs = Math.abs(c).toFixed(2);
    return { text: (up ? "+" : "−") + abs + "%", up };
  };

  const all = [...base, ...base];
  return (
    <div className="ticker" aria-label="Market reference ticker">
      <div className="ticker__inner">
        <span className="ticker__badge">
          <span className="ticker__pulse" />
          LIVE · MKT REF
        </span>
        <div className="ticker__track">
          {all.map((it, i) => {
            const c = chg(it);
            return (
              <span className="ticker__item" key={i}>
                <span className="sym">{it.sym}</span>
                <span className="val">{fmt(it)}</span>
                <span className={`chg ${c.up ? "up" : "dn"}`}>
                  <span className="chg-caret">{c.up ? "▲" : "▼"}</span>
                  {c.text}
                </span>
                <span aria-hidden="true" className="ticker__sep">·</span>
              </span>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// Capability card
function Capability({ num, title, desc }) {
  return (
    <div className="cap" role="article">
      <div className="cap__num">{num}</div>
      <div className="cap__body">
        <h3 className="cap__title">{title}</h3>
        <p className="cap__desc">{desc}</p>
        <span className="cap__arrow">
          Learn more
          <svg width="14" height="10" viewBox="0 0 14 10" fill="none"><path d="M1 5H13M13 5L9 1M13 5L9 9" stroke="currentColor" strokeWidth="1.2" /></svg>
        </span>
      </div>
    </div>
  );
}

// Article card
function Article({ lead = false, cat, date, title, dek, author, initials, variant, tone }) {
  return (
    <article className={`art ${lead ? "art--lead" : ""}`}>
      <div className="art__meta">
        <span className="art__cat">{cat}</span>
        <span>{date}</span>
      </div>
      <ArticleThumb variant={variant} tone={tone} />
      <h3 className="art__title">{title}</h3>
      <p className="art__dek">{dek}</p>
      <div className="art__foot">
        <div className="art__author">
          <div className="art__avatar">{initials}</div>
          <span>{author}</span>
        </div>
        <span>6 min read</span>
      </div>
    </article>
  );
}

// Arrow icon
function Arrow({ size = 14 }) {
  return (
    <svg className="arrow" width={size} height={size * (10/14)} viewBox="0 0 14 10" fill="none" aria-hidden="true">
      <path d="M1 5H13M13 5L9 1M13 5L9 9" stroke="currentColor" strokeWidth="1.2" />
    </svg>
  );
}

Object.assign(window, {
  BrandLockup, HeroGeometry, CtaGeometry, ArticleThumb,
  Ticker, Capability, Article, Arrow,
  SiteNav, SiteFooter,
});

function SiteNav({ active }) {
  const L = (href, label, key) => (
    <a href={href} className={active === key ? "is-active" : ""}>{label}</a>
  );
  return (
    <nav className="nav" data-screen-label="Nav">
      <div className="wrap nav__row">
        <a href="index.html" className="nav__brand" aria-label="CEU Quant Lab home">
          <BrandLockup size="sm" />
        </a>
        <div className="nav__links">
          {L("index.html#research", "Research", "research")}
          {L("index.html#articles", "Articles", "articles")}
          {L("index.html#events", "Events", "events")}
          {L("about.html", "About", "about")}
          {L("index.html#partners", "Partners", "partners")}
          {L("index.html#contact", "Contact", "contact")}
        </div>
        <a href="index.html#partner" className="btn btn--primary nav__cta">
          Partner with Us <Arrow />
        </a>
      </div>
    </nav>
  );
}

function SiteFooter() {
  return (
    <footer className="foot" id="contact" data-screen-label="Footer">
      <div className="wrap">
        <div className="foot__top">
          <div className="foot__brand">
            <BrandLockup variant="onTeal" size="md" />
            <p>
              A student-led applied research lab in finance, data science, strategy and
              markets at Central European University. Budapest · Vienna. Est. 2022.
            </p>
          </div>
          <div className="foot__col">
            <h4>Research</h4>
            <ul>
              <li><a href="#">Market Insights</a></li>
              <li><a href="#">Working Papers</a></li>
              <li><a href="#">Strategy & Consulting</a></li>
              <li><a href="#">AI & Data Science</a></li>
            </ul>
          </div>
          <div className="foot__col">
            <h4>Lab</h4>
            <ul>
              <li><a href="about.html">About</a></li>
              <li><a href="#">Team</a></li>
              <li><a href="#">Events</a></li>
              <li><a href="#">Careers</a></li>
            </ul>
          </div>
          <div className="foot__col">
            <h4>Contact</h4>
            <ul>
              <li><a href="mailto:desk@quantlab.ceu.edu">desk@quantlab.ceu.edu</a></li>
              <li><a href="#">LinkedIn</a></li>
              <li><a href="#">Newsletter</a></li>
              <li><a href="#">Press</a></li>
            </ul>
          </div>
        </div>
        <div className="foot__bottom">
          <span>© 2026 CEU Quant Lab — All rights reserved</span>
          <span>Budapest · Vienna · Est. 2022</span>
        </div>
      </div>
    </footer>
  );
}
