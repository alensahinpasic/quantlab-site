// About page composition for CEU Quant Lab
const { useEffect } = React;

function AboutHero() {
  const today = new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
  return (
    <section className="aboutHero" data-screen-label="About hero">
      <div className="wrap">
        <div className="aboutHero__grid">
          <div>
            <div className="aboutHero__meta">
              <span className="dot" />
              <span>About the Lab</span>
              <span className="sep" />
              <span>{today.toUpperCase()}</span>
              <span className="sep" />
              <span>Est. 2022 · Budapest · Vienna</span>
            </div>
            <h1 className="h1">About <em className="accent-underline">CEU Quant Lab.</em></h1>
            <p className="aboutHero__sub">
              Applied finance, data science, and strategy at Central European University —
              a research community that trains the next generation of analysts, consultants
              and builders to the standard of industry practice.
            </p>
          </div>
          <aside className="aboutHero__card" aria-label="About card">
            <HeroGeometry />
            <div className="aboutHero__card-top">
              <div className="aboutHero__card-label">Charter · 2026</div>
            </div>
            <div className="aboutHero__card-bottom">
              <div className="aboutHero__card-body">
                “Rigor over rhetoric. Evidence over opinion. Decisions, not decks.”
              </div>
              <div className="aboutHero__card-meta">The Lab’s operating principle</div>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}

function Mission() {
  return (
    <section className="mission" data-screen-label="Mission">
      <div className="wrap">
        <div className="mission__inner">
          <div>
            <div className="section__eyebrow-row">
              <span className="line" />
              <span className="num">01 — Mission</span>
            </div>
            <div className="mission__label">Our purpose</div>
          </div>
          <p className="mission__quote">
            Closing the gap between <span className="emph">academic theory</span> and
            real-world decision-making across finance, strategy, and data.
          </p>
        </div>
      </div>
    </section>
  );
}

function HowWeWork() {
  const pillars = [
    {
      n: "01", title: "Analytical Rigor",
      desc: "Every conclusion is traceable to data, assumptions, and a reproducible model. We treat research like an auditor would.",
      bullets: ["Peer review", "Reproducible models", "Clear assumptions"],
    },
    {
      n: "02", title: "Applied Learning",
      desc: "Members work on live problems — market notes, commissioned cases, partner briefs — not abstract classroom exercises.",
      bullets: ["Live case work", "Industry briefs", "Shipped outputs"],
    },
    {
      n: "03", title: "Strategic Thinking",
      desc: "Analysis is only useful when it drives a decision. We frame questions the way practitioners do: what to do, and why it matters.",
      bullets: ["Decision framing", "Structured reasoning", "Executive-level communication"],
    },
  ];
  return (
    <section className="section section--tight" data-screen-label="How we work">
      <div className="wrap">
        <div className="section__head">
          <div>
            <div className="section__eyebrow-row">
              <span className="line" />
              <span className="num">02 — How we work</span>
            </div>
            <h2 className="h2">Three principles that run through everything we publish.</h2>
          </div>
          <p>
            The Lab is built on three operating principles — applied consistently from
            desk notes to working papers to industry roundtables.
          </p>
        </div>
        <div className="pillars">
          {pillars.map(p => (
            <div className="pillar" key={p.n}>
              <div className="pillar__num">{p.n}</div>
              <h3 className="pillar__title">{p.title}</h3>
              <p className="pillar__desc">{p.desc}</p>
              <ul className="pillar__bullets">
                {p.bullets.map(b => <li key={b}>{b}</li>)}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Community() {
  return (
    <section data-screen-label="Community" style={{ borderBottom: "1px solid var(--rule)" }}>
      <div className="wrap" style={{ paddingTop: 96, paddingBottom: 24 }}>
        <div className="section__head" style={{ marginBottom: 40 }}>
          <div>
            <div className="section__eyebrow-row">
              <span className="line" />
              <span className="num">03 — The Community</span>
            </div>
            <h2 className="h2">A cross-disciplinary research community.</h2>
          </div>
          <p>
            Quant Lab brings together students across economics, finance, business,
            data science and computer science — working alongside faculty and industry
            to produce analysis that practitioners actually use.
          </p>
        </div>
      </div>
      <div className="wrap" style={{ paddingBottom: 96 }}>
        <div className="community">
          <div className="community__text">
            <h2 className="h2" style={{ fontSize: "clamp(24px, 2.4vw, 32px)" }}>
              Built by students who want to work at the standard of industry.
            </h2>
            <p>
              Members come from across CEU’s graduate programmes — many with prior
              experience at banks, consultancies and technology firms — and share an
              interest in using quantitative methods to answer real business questions.
            </p>
            <p>
              We work in small desks, publish under our own names, and hold each
              other to a standard closer to a research firm than a student society.
            </p>
            <div className="community__tags">
              <span className="chip"><span className="dot" />Finance</span>
              <span className="chip"><span className="dot" />Consulting</span>
              <span className="chip"><span className="dot" />Business</span>
              <span className="chip"><span className="dot" />Technology</span>
              <span className="chip"><span className="dot" />Data science</span>
            </div>
          </div>
          <div className="community__visual">
            <HeroGeometry />
            <div className="community__visual-content">
              <div className="community__visual-kicker">By the numbers</div>
              <div style={{ fontFamily: "'Instrument Serif', serif", fontStyle: "italic", fontSize: 34, lineHeight: 1.15, maxWidth: "20ch" }}>
                Four desks. One standard. A shared room in Budapest.
              </div>
              <div className="community__stats">
                <div className="community__stat">
                  <div className="num">300<span className="unit">+</span></div>
                  <div className="lbl">Participants across cohorts and live events</div>
                </div>
                <div className="community__stat">
                  <div className="num">4</div>
                  <div className="lbl">Research desks — Equity · Macro · Strategy · Data</div>
                </div>
                <div className="community__stat">
                  <div className="num">12</div>
                  <div className="lbl">Research notes published this year</div>
                </div>
                <div className="community__stat">
                  <div className="num">2</div>
                  <div className="lbl">CEU partners — Career Services and Economics</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function GainIcon({ kind }) {
  const s = { stroke: "currentColor", strokeWidth: 1.4, fill: "none", strokeLinecap: "round", strokeLinejoin: "round" };
  if (kind === "chart") return (<svg width="20" height="20" viewBox="0 0 20 20" {...s}><polyline points="2,15 6,11 10,13 14,7 18,4" /><line x1="2" y1="18" x2="18" y2="18" /></svg>);
  if (kind === "strat") return (<svg width="20" height="20" viewBox="0 0 20 20" {...s}><circle cx="10" cy="10" r="7" /><path d="M10 3 L10 17 M3 10 L17 10" /></svg>);
  if (kind === "data")  return (<svg width="20" height="20" viewBox="0 0 20 20" {...s}><ellipse cx="10" cy="5" rx="7" ry="2.5" /><path d="M3 5v10c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5V5" /><path d="M3 10c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5" /></svg>);
  return (<svg width="20" height="20" viewBox="0 0 20 20" {...s}><rect x="3" y="6" width="14" height="10" /><path d="M7 6V4a3 3 0 0 1 6 0v2" /></svg>);
}

function Gains() {
  const cards = [
    { icon: "chart", title: "Market & Financial Analysis", desc: "Valuation frameworks, market modelling, and equity/FX/rates analysis published under your own byline.", tags: "Equities · FX · Rates" },
    { icon: "strat", title: "Strategic Problem Solving", desc: "Case-based reasoning, structured problem decomposition, and executive-level communication.", tags: "Frameworks · Hypotheses · Briefs" },
    { icon: "data",  title: "Data & Quantitative Skills", desc: "Python, SQL, statistical inference and machine-learning techniques applied to real datasets.", tags: "Python · SQL · ML" },
    { icon: "bag",   title: "Industry Exposure", desc: "Closed-door roundtables, mentor conversations and direct introductions to partner firms.", tags: "Roundtables · Mentors · Intros" },
  ];
  return (
    <section className="section section--tight" data-screen-label="What you gain">
      <div className="wrap">
        <div className="section__head">
          <div>
            <div className="section__eyebrow-row">
              <span className="line" />
              <span className="num">04 — What you gain</span>
            </div>
            <h2 className="h2">Skills that compound across careers.</h2>
          </div>
          <p>
            Members leave the Lab with portfolios of published work, a working command
            of the technical toolkit used in industry, and a network across finance,
            consulting and technology.
          </p>
        </div>
        <div className="gains">
          {cards.map((c, i) => (
            <div className="gain" key={i}>
              <div className="gain__icon"><GainIcon kind={c.icon} /></div>
              <h3 className="gain__title">{c.title}</h3>
              <p className="gain__desc">{c.desc}</p>
              <div className="gain__tags">{c.tags}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Timeline() {
  return (
    <section className="section section--tight" data-screen-label="Timeline" style={{ background: "var(--paper-2)" }}>
      <div className="wrap">
        <div className="section__head">
          <div>
            <div className="section__eyebrow-row">
              <span className="line" />
              <span className="num">05 — Timeline</span>
            </div>
            <h2 className="h2">From first note to institutional partnership.</h2>
          </div>
          <p>
            A short history, the current state of the Lab, and the work ahead — kept
            intentionally brief.
          </p>
        </div>
        <div className="timeline">
          <div className="tcol">
            <div className="tcol__year">2022<span className="sub">Founded</span></div>
            <h3 className="tcol__title">A reading group becomes a research lab.</h3>
            <p className="tcol__desc">
              Founded by CEU graduate students in economics and business to bring
              practitioner-grade analysis into the university.
            </p>
            <ul className="tcol__list">
              <li>First desk note published</li>
              <li>Charter and editorial standards</li>
              <li>Initial cohort of 22 members</li>
            </ul>
          </div>
          <div className="tcol tcol--now">
            <div className="tcol__year">2026<span className="sub">Today</span></div>
            <h3 className="tcol__title">Four desks, institutional partnerships.</h3>
            <p className="tcol__desc">
              Equity, Macro, Strategy and Data desks publishing weekly, working with CEU
              Career Services and Economics, and hosting industry roundtables.
            </p>
            <ul className="tcol__list">
              <li>300+ participants across cohorts</li>
              <li>12 research notes this year</li>
              <li>Commissioned strategy case work</li>
            </ul>
          </div>
          <div className="tcol">
            <div className="tcol__year">Next<span className="sub">Future</span></div>
            <h3 className="tcol__title">Alumni network and an annual review.</h3>
            <p className="tcol__desc">
              Expanding into a formal alumni network across finance and consulting, and
              publishing an annual CEE research review alongside partner institutions.
            </p>
            <ul className="tcol__list">
              <li>Alumni mentoring programme</li>
              <li>Annual CEE review</li>
              <li>Applied-AI research track</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

function AboutCTA() {
  return (
    <section className="finalCta" id="join" data-screen-label="About CTA">
      <CtaGeometry />
      <div className="wrap">
        <div className="finalCta__grid">
          <div>
            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: "rgba(255,255,255,0.6)", marginBottom: 20 }}>
              Join the Lab — Spring 2026 intake
            </div>
            <h2>
              Develop skills for careers in <em>finance, consulting, business, and technology.</em>
            </h2>
          </div>
          <div className="finalCta__aside">
            <p>
              Members work on published research, commissioned industry cases and
              applied-AI projects — graduating with a portfolio of work under their own name.
            </p>
            <div className="finalCta__ctas">
              <a href="#" className="btn btn--on-dark">Apply to join <Arrow /></a>
              <a href="index.html#partner" className="btn btn--on-dark-ghost">Partner with us</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function AboutApp() {
  const useTweaks = window.useTweaks;
  const [tweaks, setTweak] = useTweaks
    ? useTweaks(window.__TWEAKS__)
    : [window.__TWEAKS__, () => {}];

  useEffect(() => {
    const r = document.documentElement.style;
    r.setProperty("--primary", tweaks.primary);
    r.setProperty("--secondary", tweaks.secondary);
    r.setProperty("--accent", tweaks.accent);
    r.setProperty("--paper", tweaks.paper);
    r.setProperty("--ink", tweaks.ink);
    document.body.style.background = tweaks.paper;
  }, [tweaks.primary, tweaks.secondary, tweaks.accent, tweaks.paper, tweaks.ink]);

  const { TweaksPanel, TweakSection, TweakColor, TweakToggle } = window;

  return (
    <>
      <SiteNav active="about" />
      <AboutHero />
      {tweaks.showTicker && <Ticker />}
      <Mission />
      <HowWeWork />
      <Community />
      <Gains />
      <Timeline />
      <AboutCTA />
      <SiteFooter />
      {TweaksPanel && (
        <TweaksPanel title="Tweaks">
          <TweakSection label="Palette">
            <TweakColor label="Primary" value={tweaks.primary} onChange={v => setTweak("primary", v)} />
            <TweakColor label="Secondary" value={tweaks.secondary} onChange={v => setTweak("secondary", v)} />
            <TweakColor label="Accent" value={tweaks.accent} onChange={v => setTweak("accent", v)} />
            <TweakColor label="Paper" value={tweaks.paper} onChange={v => setTweak("paper", v)} />
            <TweakColor label="Ink" value={tweaks.ink} onChange={v => setTweak("ink", v)} />
          </TweakSection>
          <TweakSection label="Modules">
            <TweakToggle label="Show market ticker" value={tweaks.showTicker} onChange={v => setTweak("showTicker", v)} />
          </TweakSection>
        </TweaksPanel>
      )}
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<AboutApp />);
